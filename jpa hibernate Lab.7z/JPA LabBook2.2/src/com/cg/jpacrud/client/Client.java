package com.cg.jpacrud.client;

import com.cg.jpacrud.entities.Author;
import com.cg.jpacrud.entities.Book;
import com.cg.jpacrud.service.BookService;
import com.cg.jpacrud.service.BookServiceImpl;

public class Client {

	public static void main(String[] args) {

		BookService service = new BookServiceImpl();
		
		Book b=new Book();
		b.setId(101);
		b.setTitle("Quantum Physics");
		b.setAuthor("Danny Coward");
		b.setPrice(600.00);
		
		Book b2=new Book();
		b2.setId(103);
		b2.setTitle("Quantative Apptitude");
		b2.setAuthor("Arun Shrama");
		b2.setPrice(1200.00);
		//
		Book b1=new Book();
		b1.setId(102);
		b1.setTitle("Quantative Apptitude");
		b1.setAuthor("R S Agrawal");
		b1.setPrice(700.00);
		
		Author au=new Author();
		au.setID(201);
		au.setName("Danny Coward");
		service.addBook(b);
		service.addAuthor(au);
		service.addBook(b1);
		service.addBook(b2);
		
		System.out.println("************Listing total number of books*************");
		System.out.println("Total books:"+service.getBookCount());
		
		System.out.println("************Listing book with id 102*************");
		System.out.println("Book with ID 101:"+service.getBookById(102));
		
		System.out.println("************Listing All books*************");
		for(Book book:service.getAllBooks()) {
			System.out.println(book);
		}
		
		
		
		System.out.println("************Listing book written by Danny Coward*************");
		for(Book book:service.getAuthorBooks("Danny Coward") ) {
			System.out.println(book);
		}
		
		System.out.println("************Listing book on Android*************");
		for(Book book:service.getBookByTitle("Android")) {
			System.out.println(book);
		}
		
		
		
		System.out.println("************Listing All books between 500 and 1000*************");
		for(Book book:service.getBooksInPriceRange(500, 1000) ) {
			System.out.println(book);
		}
		
		
		
		

	}
}
